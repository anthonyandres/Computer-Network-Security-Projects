public class SiriProtocol {


    public String processInput(String theInput){
        String theOutput = null;


        return theOutput;
    }








}
